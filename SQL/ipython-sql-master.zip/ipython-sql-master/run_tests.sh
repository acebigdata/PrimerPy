ipython -c "import nose; nose.run()"
# Insert breakpoints with `from nose.tools import set_trace; set_trace()`
